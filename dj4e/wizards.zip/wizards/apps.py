from django.apps import AppConfig


class WizardsConfig(AppConfig):
    name = 'wizards'
