from django.contrib import admin
from wizards.models import House, Wizard

# Register your models here.

admin.site.register(House)
admin.site.register(Wizard)
