from django.apps import AppConfig


class AdsConfig(AppConfig):
    name = 'ads'
