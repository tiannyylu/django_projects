from django.apps import AppConfig


class UnescoConfig(AppConfig):
    name = 'unesco'
